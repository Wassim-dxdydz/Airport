package fr.uga.miage.m1.repositories

import backend.common.src.main.kotlin.fr.uga.miage.m1.enums.AvionEtat
import fr.uga.miage.m1.models.Avion
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ActiveProfiles
import reactor.test.StepVerifier
import java.util.*

@ActiveProfiles("test")
class SimpleAvionTest : RepoBase() {

    @Autowired
    lateinit var repo: AvionRepository

    @BeforeEach
    fun cleanup() {
        // Clean all data before each test
        repo.deleteAll().block()
    }

    @Test
    fun `simple save and find`() {
        val immatriculation = "F-TEST-${UUID.randomUUID()}"

        // Don't provide ID - let database generate it
        val avion = Avion(
            immatriculation = immatriculation,
            type = "A320",
            capacite = 180,
            etat = AvionEtat.EN_SERVICE
        )

        println("Testing with: $immatriculation")

        // Test save
        StepVerifier.create(repo.save(avion))
            .expectNextMatches { saved ->
                println("Saved: ${saved.immatriculation}, ID: ${saved.id}")
                saved.immatriculation == immatriculation &&
                        saved.id != null && // ID should be generated
                        saved.type == "A320" &&
                        saved.capacite == 180
            }
            .verifyComplete()

        // Then test finding
        StepVerifier.create(repo.findByImmatriculation(immatriculation))
            .expectNextMatches { found ->
                println("Found: ${found.immatriculation}, ID: ${found.id}")
                found.type == "A320" &&
                        found.capacite == 180 &&
                        found.id != null
            }
            .verifyComplete()
    }

    @Test
    fun `test database schema`() {
        // Simple test to verify the schema works
        val avion = Avion(
            immatriculation = "TEST-SCHEMA-${UUID.randomUUID()}",
            type = "TEST",
            capacite = 100,
            etat = AvionEtat.EN_SERVICE
        )

        StepVerifier.create(repo.save(avion))
            .expectNextCount(1)
            .verifyComplete()
    }
}