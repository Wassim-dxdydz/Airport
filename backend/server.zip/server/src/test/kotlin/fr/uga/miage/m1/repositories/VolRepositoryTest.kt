package fr.uga.miage.m1.repositories

import backend.common.src.main.kotlin.fr.uga.miage.m1.enums.VolEtat
import backend.common.src.main.kotlin.fr.uga.miage.m1.enums.AvionEtat
import fr.uga.miage.m1.models.Vol
import fr.uga.miage.m1.models.Avion
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.test.context.ActiveProfiles
import reactor.test.StepVerifier
import java.time.LocalDateTime
import java.util.*

@ActiveProfiles("test")
class VolRepositoryTest : RepoBase() {

    @Autowired
    lateinit var repo: VolRepository

    @Autowired
    lateinit var avionRepository: AvionRepository

    @BeforeEach
    fun cleanup() {
        repo.deleteAll().block()
        avionRepository.deleteAll().block()
    }

    @Test
    fun `save and find by numeroVol`() {
        // Create avion first
        val avion = avionRepository.save(
            Avion(
                id = UUID.randomUUID(),
                immatriculation = "F-TEST-${UUID.randomUUID()}",
                type = "A320",
                capacite = 180,
                etat = AvionEtat.EN_SERVICE
            )
        ).block()!!

        val vol = Vol(
            id = UUID.randomUUID(),
            numeroVol = "AF1234-${UUID.randomUUID()}",
            avionId = avion.id,
            origine = "LYS",
            destination = "CDG",
            heureDepart = LocalDateTime.now().plusHours(1),
            heureArrivee = LocalDateTime.now().plusHours(3),
            etat = VolEtat.PREVU
        )

        StepVerifier.create(repo.save(vol))
            .expectNextMatches {
                it.numeroVol == vol.numeroVol &&
                        it.avionId == avion.id &&
                        it.origine == "LYS" &&
                        it.destination == "CDG" &&
                        it.etat == VolEtat.PREVU
            }
            .verifyComplete()

        StepVerifier.create(repo.findByNumeroVol(vol.numeroVol))
            .expectNextMatches {
                it.etat == VolEtat.PREVU &&
                        it.origine == "LYS" &&
                        it.destination == "CDG" &&
                        it.numeroVol == vol.numeroVol
            }
            .verifyComplete()
    }

    @Test
    fun `find by etat`() {
        // Create avion for the vol
        val avion = avionRepository.save(
            Avion(
                id = UUID.randomUUID(),
                immatriculation = "F-TEST-${UUID.randomUUID()}",
                type = "B737",
                capacite = 160,
                etat = AvionEtat.EN_SERVICE
            )
        ).block()!!

        val vol = Vol(
            id = UUID.randomUUID(),
            numeroVol = "AF5678-${UUID.randomUUID()}",
            avionId = avion.id,
            origine = "CDG",
            destination = "JFK",
            heureDepart = LocalDateTime.now().plusHours(2),
            heureArrivee = LocalDateTime.now().plusHours(4),
            etat = VolEtat.EN_VOL
        )

        StepVerifier.create(
            repo.save(vol)
                .thenMany(repo.findByEtat(VolEtat.EN_VOL))
        )
            .expectNextMatches {
                it.numeroVol == vol.numeroVol &&
                        it.etat == VolEtat.EN_VOL &&
                        it.origine == "CDG" &&
                        it.destination == "JFK"
            }
            .verifyComplete()
    }

    @Test
    fun `find by avionId`() {
        // Create an avion for the test
        val avion = avionRepository.save(
            Avion(
                id = UUID.randomUUID(),
                immatriculation = "F-TEST-${UUID.randomUUID()}",
                type = "A380",
                capacite = 500,
                etat = AvionEtat.EN_SERVICE
            )
        ).block()!!

        val vol1 = Vol(
            id = UUID.randomUUID(),
            numeroVol = "AF9012-${UUID.randomUUID()}",
            avionId = avion.id,
            origine = "LYS",
            destination = "CDG",
            heureDepart = LocalDateTime.now().plusHours(1),
            heureArrivee = LocalDateTime.now().plusHours(3),
            etat = VolEtat.PREVU
        )

        val vol2 = Vol(
            id = UUID.randomUUID(),
            numeroVol = "AF3456-${UUID.randomUUID()}",
            avionId = avion.id,
            origine = "CDG",
            destination = "NCE",
            heureDepart = LocalDateTime.now().plusHours(5),
            heureArrivee = LocalDateTime.now().plusHours(7),
            etat = VolEtat.PREVU
        )

        StepVerifier.create(
            repo.save(vol1)
                .then(repo.save(vol2))
                .thenMany(repo.findByAvionId(avion.id!!))
        )
            .expectNextCount(2)
            .verifyComplete()
    }

    @Test
    fun `update vol etat`() {
        val avion = avionRepository.save(
            Avion(
                id = UUID.randomUUID(),
                immatriculation = "F-TEST-${UUID.randomUUID()}",
                type = "A320",
                capacite = 180,
                etat = AvionEtat.EN_SERVICE
            )
        ).block()!!

        val vol = Vol(
            id = UUID.randomUUID(),
            numeroVol = "AF7890-${UUID.randomUUID()}",
            avionId = avion.id,
            origine = "MRS",
            destination = "ORY",
            heureDepart = LocalDateTime.now().plusHours(1),
            heureArrivee = LocalDateTime.now().plusHours(3),
            etat = VolEtat.PREVU
        )

        StepVerifier.create(
            repo.save(vol)
                .flatMap { savedVol ->
                    val updatedVol = savedVol.copy(
                        etat = VolEtat.ANNULE
                    )
                    repo.save(updatedVol)
                }
        )
            .expectNextMatches {
                it.etat == VolEtat.ANNULE &&
                        it.origine == "MRS" &&
                        it.destination == "ORY" &&
                        it.createdAt != null
            }
            .verifyComplete()

        StepVerifier.create(repo.findByEtat(VolEtat.ANNULE))
            .expectNextMatches {
                it.numeroVol == vol.numeroVol &&
                        it.origine == "MRS" &&
                        it.destination == "ORY"
            }
            .verifyComplete()
    }
}